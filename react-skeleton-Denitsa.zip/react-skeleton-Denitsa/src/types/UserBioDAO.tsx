export type UserBioDAO={
   id: number;

   caption: string;
   content: string;
   dateOfBirth: string;
   country: string;
   city:

}
