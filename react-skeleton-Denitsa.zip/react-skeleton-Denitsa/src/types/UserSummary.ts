import Media from './Media'
import

export type UserSummary ={
  id: number;
  name: string;
  userName: string;
  avatar: Media
  userBio?: userBioDAO
}
