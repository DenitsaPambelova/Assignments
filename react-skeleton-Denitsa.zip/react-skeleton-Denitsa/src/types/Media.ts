export type Media= {
  id: number;
  filPath: string;
  fileSize: number;
  mimeType: string;
}
