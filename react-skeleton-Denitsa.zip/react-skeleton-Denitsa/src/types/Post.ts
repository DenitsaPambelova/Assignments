import {Comment} from './Comment'
import { Media} from './Media'
import { UserSummary } from './UserSummary';
import {UserSummaryDAO} from'./UserSummary'

export type PostDAO = {
  id: number;
  title: string;
  content: string;
  comments: Comment[];
  media?: Media;
}
