import UserSummaryDAO
import Media

export type Comment ={
  id: number;
  content: string;
  user: UserSummaryDAO;
  media?: Media;

}
