import React, {Component} from 'react';
// import {AppLogo} from 'components/domain';
// import {NavBrand} 'components/generic';
// import {MainContent, Navbar} from  '../components/layout/NavBar';
import Navbar from  '../components/layout/NavBar';
import NavBar from '../components/layout/NavBar';
//import 'NewsFeed' from



//import {Post, Media, UserSummary, } from '../types/UserSummary';

class App extends Component {
  render() {
    return (

      <div>
        <NavBar>My navigation</NavBar>NavBar>
      </div>

    );
  }
}

export default App;
