import {Post} from 'types'
const createPost  = (numberOfPosts: number): Post[] =>{
  const posts=[]

  for (let i=1;i< numberOfPosts;i++){
    posts.push({
      id: i,
      title: "Lorem ipusm...",
      content: makeId(),
      comments:createComments(2)
    })
  }
}
