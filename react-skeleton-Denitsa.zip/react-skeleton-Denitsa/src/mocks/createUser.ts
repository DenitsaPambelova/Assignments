import {UserSummary} from '../types/UserSummary';
improt {makeId} from './utils'
export const createUserSumary =(): UserSummary=>{
  reaturn {id: Marh.ceil(Math.Random()*1000),

}
