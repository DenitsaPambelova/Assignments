import 'makeId' from './utils'

const createComments= (numberOfCommenmts: number) =>{

}
