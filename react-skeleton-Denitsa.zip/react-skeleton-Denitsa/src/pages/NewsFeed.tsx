import React, {Component} from 'react';
import {Post} from 'types';
import {createPosts} from 'mocks/CreatePosts'
import {PostsLit} from 'components/domain/Post/PostsList'


type State={
  posts: PostDAO[];
}

export default class NewsFeed extends Component<{}, State>{
  state = State {
    posts=[]

}

componentDidMount(){
  const generatedPosts=createPosts(5)
  this.setState({posts: generatedPosts})
}

render(){
  <PostList posts={this.state.posts}/>
}
