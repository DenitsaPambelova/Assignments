import sys


def check_elements(prev_list):
    count = 0
    temp_list = prev_list.copy()
    for pos1 in prev_list:
        i1, j1 = pos1
        temp_list.remove(pos1)
        for pos2 in temp_list:
            i2, j2 = pos2
            if (i1 == i2 and (j1 == j2 + 1 or j1 == j2 - 1)) or (j1 == j2 and (i1 == i2 + 1 or i1 == i2 - 1)):
                count += 1
                break
        temp_list.append(pos1)
    return count


def check_adj_equals_matrix(matrix, m, n):
    occur_list = {}
    count = {}

    for i in range(m):
        for j in range(n):
            char = matrix[i][j]
            if char in occur_list:
                occur_list[char] += [(i, j)]
            else:
                occur_list[char] = [(i, j)]
                count[char] = 0

    for char in occur_list:
        count[char] = check_elements(occur_list[char])
    arr = []
    for key, val in count.items():

        if val:
            arr.extend([val])
    return max(arr)


if __name__ == '__main__':

    with open('test_1') as f:
        matrix1 = [line.rstrip().split() for line in f]
    n = int(matrix1[0][0])
    m = int(matrix1[0][1])
    matrix1.pop(0)
    result = check_adj_equals_matrix(matrix1, m, n)
    print(result)

    with open('test_2') as f:
        matrix1 = [line.rstrip().split() for line in f]
    n = int(matrix1[0][0])
    m = int(matrix1[0][1])
    matrix1.pop(0)
    result = check_adj_equals_matrix(matrix1, m, n)
    print(result)

    with open('test_3') as f:
        matrix1 = [line.rstrip().split() for line in f]
    n = int(matrix1[0][0])
    m = int(matrix1[0][1])
    matrix1.pop(0)
    result = check_adj_equals_matrix(matrix1, m, n)
    print(result)

    with open('test_4') as f:
        matrix1 = [line.rstrip().split() for line in f]
    n = int(matrix1[0][0])
    m = int(matrix1[0][1])
    matrix1.pop(0)
    result = check_adj_equals_matrix(matrix1, m, n)
    print(result)
